#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <GL/glut.h>
#include <math.h>
#include "octa_dis.h"
#include <iostream>
#include <fstream>
#define PI 3.14159265

using namespace std;

GLsizei ww = 700, wh = 700;
GLdouble orthoX = 700, orthoY = 700;
GLint wcx = 180, wcy = 180;
int xTrack, yTrack;					//tracks mouse movement
int moveX, moveY;					//possibly used later for animation
int pt;
float rotSpeed[2];					//to be possibly used later for automatic rotation

bool tracking = false;				//true when left mouse is held down

double rotation[2] = {0,0};			//keeps track of current rotation
GLfloat project_points[25][3];


//calculate the norm from three points
//could be optimized a bit
Point norm(GLfloat a[3], GLfloat b[3], GLfloat c[3])
{
	GLfloat v1[3] = {a[0] - c[0], a[1] - c[1], a[2] - c[2]};
	GLfloat v2[3] = {b[0] - c[0], b[1] - c[1], b[2] - c[2]};

	Point n = {(v1[1] * v2[2]) - (v1[2] * v2[1]),
		(v1[2] * v2[0]) - (v1[0] * v2[2]),
		(v1[0] * v2[1]) - (v1[1] * v2[0])};

	return n;
}

void crossProduct(GLfloat l1[], GLfloat l2[], GLfloat l3[]) {
   l3[0] = l1[1] * l2[2] - l1[2] * l2[1];
   l3[1] = -(l1[0] * l2[2] - l1[2] * l2[0]);
   l3[2] = l1[0] * l2[1] - l1[1] * l2[0];
}
void substitute(GLfloat l3[],GLfloat A[3], GLfloat l4[]){
//    GLfloat l4[4];
    l4[0] = l3[0];
    l4[1] = l4[1];
    l4[2] = l4[2];
    l4[3] = l4[3];
    l4[4] = -l3[0]*A[0] - l3[1]*A[1] - l3[2]*A[2];

}
void shortest_distance(GLfloat x1, GLfloat y1,
                       GLfloat z1, GLfloat a,
                       GLfloat b, GLfloat c,
                       GLfloat d, GLfloat dist)
{

    d = fabs((a * x1 + b * y1 +
              c * z1 + d));
    GLfloat e = sqrt(a * a + b *
                   b + c * c);
    dist = d/e;

}
//The function calculates all the projection steps of the external point onto the planes of octahedron
void planeqn(void){

    GLfloat A[3]; GLfloat B[3]; GLfloat C[3]; GLfloat l1[3]; GLfloat l2[3];
    int i = 0;
    int j =0;
    GLfloat x, y,z,a,b,c,d,e,f,t;
    GLfloat l3[3];
    GLfloat l4[4];
    GLfloat eqn[8][4];
    GLfloat all_dist[8];
    GLfloat min_dist[5];
    GLfloat mi = 0;
    int mit= 0;

    //Firstly we calculate the equation of the planes, with the help of the 3 points which lie on the plane. By the cross-product of the 2 vectors in the direction of 2 points.
        for (i; i<8; i++){
            A[0]= vertices[octaIndices[i*3 + 1]][0];
            A[1]= vertices[octaIndices[i*3 + 1]][1];
            A[2]= vertices[octaIndices[i*3 + 1]][2];
            B[0]= vertices[octaIndices[i*3 + 2]][0];
            B[1]= vertices[octaIndices[i*3 + 2]][1];
            B[2]= vertices[octaIndices[i*3 + 2]][2];
            C[0]= vertices[octaIndices[i*3]][0];
            C[1]= vertices[octaIndices[i*3]][1];
            C[2]= vertices[octaIndices[i*3]][2];

            l1[0] = B[0]-A[0];
            l1[1] = B[1] - A[1];
            l1[2] = B[2] - A[2];
            l2[0] = C[0]-A[0];
            l2[1] = C[1] - A[1];
            l2[2] = C[2] - A[2];

            crossProduct(l1, l2, l3);
            substitute(l3, A, l4);
            eqn[i][0] = l4[0];
            eqn[i][1] = l4[1];
            eqn[i][2] = l4[2];
            eqn[i][3] = l4[3];

        }
        //Then we calculate the distance of the 25 external points with all the plane equations to find the minimum distance.
        for (j; j<25; j++){
                GLfloat all_dist[8];
                for (i =0; i<8; i++){
                    GLfloat dist;
                    shortest_distance(points[j][0], points[j][1], points[j][2], eqn[i][0], eqn[i][1], eqn[i][2], eqn[i][3], dist);
                    all_dist[i] = dist;}

                mi = all_dist[0];
                //Then we find which plane does the external point lie closest too.
                for(i = 0; i < 8; i++){
                    if(all_dist[i] < mi){
                        mit = i;}}
                //Then we calculate the projected coordinates of the external point on to the plane, with normal of the plane a point that lies on the plane and the external point.
                x = points[j][0];
                y = points[j][1];
                z = points[j][2];
                a = eqn[mit][0];
                b = eqn[mit][1];
                c = eqn[mit][2];
                d = vertices[octaIndices[mit*3 + 1]][0];
                e = vertices[octaIndices[mit*3 + 1]][0];
                f = vertices[octaIndices[mit*3 + 1]][0];

                t = (a*d - a*x + b*e - b*y + c*f - c*z)/(a*a+ b*b + c*c);
                project_points[j][0] = x + t*a;
                project_points[j][1] = y + t*b;
                project_points[j][2] = z + t*c;



        }
   }



void Init()
{
    //glClearColor(1.0, 1.0, 1.0, 0.0);
    glColor3f(0.0, 0.0, 1.0);   //this one
    glPointSize(15);             //and this one

    //glMatrixMode(GL_PROJECTION);    //coordinate system
    //glLoadIdentity();
    gluOrtho2D(0.0, 1200.0, 0.0, 800.0);
}

//calculate normal of each face, draw the face
//for some reason the normal of each odd face points inwards, so they are negated
void drawOcta(void){
	GLfloat x,y;
	int i = 0;
	Point n;
    glEnable(GL_COLOR_MATERIAL);
    //GLfloat const blue[3] = {0,0,255};

	for(i; i < 8; i++){
		glColor3f(0.0f,0.0f,1.0f);

		n = norm(vertices[octaIndices[i*3 + 1]], vertices[octaIndices[i*3 + 2]], vertices[octaIndices[i*3]]);
        glBegin(GL_POINTS);
        glPointSize(5.0f);
        glVertex3d(0.0, 0.0, 1.0);
        glPointSize(5.0f);
        glVertex3d(1.0, 0.0, 0.0);
        glPointSize(5.0f);
        glVertex3d(0.0, -1.0, 0.0);
        glPointSize(5.0f);
        glVertex3d(-2.0 , 0.0, 0.0);
        glVertex3d(0.0 , 2.0, 0.0);
        glVertex3d(0.0 , 0.0, -2.0);
        glColor3f(0.0, 0.0, 1.0);
        glEnd();

        glBegin(GL_POINTS);
        glColor3f(1.0f,0.0f,0.0f);
        glPointSize(5.0f);
        glVertex3d(project_points[pt][0], project_points[pt][1], project_points[pt][2]);
        glPointSize(5.0f);
        glEnd();
        //glColor3f(0.0f, 0.0f, 1.0f);
		if(i % 2 == 0){

            glColor3f(0.0f, 0.0f, 1.0f);
			glNormal3f(n.x, n.y, n.z);


		}
		else
            glColor3f(0.0f, 0.0f, 1.0f);
			glNormal3f(- n.x, - n.y, - n.z);


		glColor3f(0.0f, 0.0f, 1.0f);

		glDrawElements(GL_LINE_STRIP, 3, GL_UNSIGNED_BYTE, &octaIndices[i*3]);
		glColor3f(0.0f, 0.0f, 1.0f);


	}


}


void ani() {

GLfloat x,y;
int i, j, k;
GLfloat pos[2];		//x,y,z
GLfloat dir[2];		//dx,dy,dz
GLint rot;		//degrees

int neg;

pos[0] = (GLfloat) x - (ww/2 - orthoX/2);
pos[1] = (GLfloat) y - (wh/2 - orthoX/2);

	//randomly set x direction (rand between -2.2 and 2.2, abs value >= .2)

	if(rand()%2 == 1) neg = 1;
	else neg = -1;
	dir[0] = .2 * neg + (float)(rand() % 100) *.02 * neg;

	//randomly set y direction (rand between -2.2 and 2.2, abs value >= .2)

	if(rand()%2 == 1) neg = 1;
	else neg = -1;
	dir[1] = .2 * neg + (float)(rand() % 100) *.02 * neg;
	rot = (GLint)(rand()%180);



		//randomly set rotation if hits a boundary
		for(k=0; k < 20; k++){
		if (pos[0] + (ww/2 - orthoX/2) > ww/2 + 149)  {
			if(dir[0] > 0) dir[0] = - dir[0];
			rot = (GLint)(rand()%180);
		}
		if (pos[0] + (ww/2 - orthoX/2) < ww/2 - 149) {
			if(dir[0] < 0) dir[0] = - dir[0];
			rot = (GLint)(rand()%180);
		}
		if (pos[1] + (wh/2 - orthoY/2) > wh/2 + 149)  {
			if(dir[1] > 0) dir[1] = - dir[1];
			rot = (GLint)(rand()%180);
		}
		if (pos[1] + (wh/2 - orthoY/2) < wh/2 - 149) {
			if(dir[1] < 0) dir[1] = - dir[1];
			rot = (GLint)(rand()%180);
		}

		}

		//displaceX += dirX * 5.0; displaceY += dirY * 3.0;
		for (i = 0; i < 20000; i++)
			for (j = 0; j < 200; j++) ;
		glutPostRedisplay ( );

}



void SetMaterial(Material m)
     /* sets the current material */
{
  glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, m.ambient);
  glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, m.diffuse);
  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, m.specular);
  glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, m.shiny);
}

void display() {

    glEnable(GL_COLOR_MATERIAL);
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	//store view matrix
	glPushMatrix();
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();

	//lights off
	glDisable(GL_LIGHT0);
	//apply rotation
	glRotated(rotation[1], 1.0, 0.0, 0.0);
	glRotated(rotation[0], 0.0, 1.0, 0.0);






	//lights on
	glEnable(GL_LIGHT0);

	//glEnable(GL_LIGHT1);    but not this light




//	SetMaterial(Brass);
	drawOcta();

    //GLfloat const blue[3] = {0,0,255};
    //glColor3fv(blue);

	//recover viewing matrix
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();



	glFlush();
	glutSwapBuffers();


}

//left mouse toggles tracking bool
void mouse(int button, int state, int x, int y) {

	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
		tracking = true;

	}
	if(button == GLUT_LEFT_BUTTON && state == GLUT_UP) {

		tracking = false;
	}

}

//tracks mouse position while mouse button is being held
void mouseTrackActive(int x, int y) {


		if(tracking == true){

			rotation[0] = rotation[0] + .7*(x - xTrack);
			if (rotation[0] >= 360) rotation[0]-=360;
			rotation[1] = rotation[1] + .7*(y - yTrack);
			if (rotation[1] >= 360) rotation[1]-=360;
		}

		xTrack = x;
		yTrack = y;
		glutPostRedisplay();
	}

//tracks mouse position while mouse button not being held
//essential to remain consistent with active mouse function
void mouseTrackPassive(int x, int y){

		xTrack = x;
		yTrack = y;
		glutPostRedisplay();
}
void takeinput(void){
    cout << "Select which point out of the 25: "; // Type the external point index you want to project.
    cin >> pt;
}

int main(int argc, char **argv) {


    takeinput();


    planeqn();
    //cout << "points" << project_points[pt][1];

    glEnable(GL_COLOR_MATERIAL);
    GLfloat lmodel_ambient[] = { 0.2, 0.2, 0.2, 1.0 };

	glutInit (&argc, argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB| GLUT_DEPTH);
	glutInitWindowSize (ww, wh);
	glutInitWindowPosition (wcx, wcy);
	glutCreateWindow ("Octahedron");
	glutDisplayFunc(display);


	glMatrixMode (GL_PROJECTION);
	glViewport (0,0, ww, wh);
	glLoadIdentity ( );
	glOrtho (-8.0, 8.0, -8.0, 8.0, -8.0, 8.0);
	glFrustum(-10.0, 10.0, -10.0, 10.0, -10.0, 10.0);

	glutIdleFunc(ani);
	glutMotionFunc(mouseTrackActive);
	glutPassiveMotionFunc(mouseTrackPassive);
	glutMouseFunc(mouse);
	glEnable(GL_DEPTH_TEST);
	glEnableClientState(GL_VERTEX_ARRAY);



	glEnable(GL_COLOR_MATERIAL);
	glColor3f(0.0f, 0.0f, 1.0f);
	GLfloat const blue[3] = {0,0,255};
	glColorPointer(3,GL_UNSIGNED_BYTE, 0, blue);
	glVertexPointer(3, GL_FLOAT, 0, &vertices);
	glShadeModel(GL_FLAT);
    glEnable(GL_LIGHTING);
    glEnable(GL_NORMALIZE);

    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
    /* set a low background light such that objects in the scene
       can be seen at all */

	glClearColor (1.0, 1.0, 1.0, 1.0);	   /*white background */


    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glMatrixMode(GL_MODELVIEW);
    Init();


	glutMainLoop();
}
